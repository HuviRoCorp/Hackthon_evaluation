-- MySQL dump 10.13  Distrib 8.0.45, for Win64 (x86_64)
--
-- Host: localhost    Database: hackathon_portal
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `judge_reports`
--

DROP TABLE IF EXISTS `judge_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `judge_reports` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `ai_remark` longtext,
  `ai_scores` longtext,
  `created_at` datetime(6) DEFAULT NULL,
  `evaluation_date` datetime(6) DEFAULT NULL,
  `final_score` double DEFAULT NULL,
  `human_remark` longtext,
  `human_scores` longtext,
  `judge_remark` longtext,
  `judge_scores` longtext,
  `justification_date` datetime(6) DEFAULT NULL,
  `submission_date` datetime(6) DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `evaluation_id` bigint NOT NULL,
  `problem_id` bigint NOT NULL,
  `submission_id` bigint NOT NULL,
  `team_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKa7qwqvlloyjxypvmnh0s9ilti` (`evaluation_id`),
  KEY `FKs4dhdxh7ms34rj0s2uvg2vaeb` (`problem_id`),
  KEY `FKqf827tv8o3bxyljajt7f4n6by` (`submission_id`),
  KEY `FK6uy6xh48l6hf9es90q0hfnytp` (`team_id`),
  CONSTRAINT `FK6uy6xh48l6hf9es90q0hfnytp` FOREIGN KEY (`team_id`) REFERENCES `teams` (`team_id`),
  CONSTRAINT `FKa7qwqvlloyjxypvmnh0s9ilti` FOREIGN KEY (`evaluation_id`) REFERENCES `evaluations` (`evaluation_id`),
  CONSTRAINT `FKqf827tv8o3bxyljajt7f4n6by` FOREIGN KEY (`submission_id`) REFERENCES `applications` (`id`),
  CONSTRAINT `FKs4dhdxh7ms34rj0s2uvg2vaeb` FOREIGN KEY (`problem_id`) REFERENCES `problem_statements` (`problem_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `judge_reports`
--

LOCK TABLES `judge_reports` WRITE;
/*!40000 ALTER TABLE `judge_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `judge_reports` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-19 11:52:17
